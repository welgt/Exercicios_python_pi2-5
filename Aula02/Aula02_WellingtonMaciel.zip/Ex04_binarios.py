def binarios(n):
    print(bin(n)[2:])

n = int(input('Informe um numero para converter em binario:\n'))
binarios(n)
