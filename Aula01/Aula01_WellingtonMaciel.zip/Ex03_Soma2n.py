n1 = int(input('Informe 2 numeros para serem somados:\n'))
n2 = int(input())

print('A soma é: ', n1+n2)