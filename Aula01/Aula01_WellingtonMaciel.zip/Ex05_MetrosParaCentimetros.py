n= float(input('Informe uma medida em metros:\n'))
m = n*1000

print('{:.2f} convertidos para milimetros é : {:.0f}'.format(n,m))