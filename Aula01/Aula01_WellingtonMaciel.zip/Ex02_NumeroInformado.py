n = int(input('Informe um numero:\n'))
print('O numero informado foi: ',n)