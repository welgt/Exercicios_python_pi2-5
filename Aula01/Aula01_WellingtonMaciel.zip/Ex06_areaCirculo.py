raio = float(input('Informe a raio do circulo:\n'))

area = 3.14*(raio**2)

print('A area do circulo  é : {:.0f}'.format(area))

